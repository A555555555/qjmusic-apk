# 清玖音乐 Pro - Android Studio 项目源码

## 功能
- Android 原生 Kotlin 项目，深色 + 绿色的音乐播放器界面
- 通过 Android 系统文件选择器导入本地音频，支持多选
- ExoPlayer/Media3 本地播放，上一首/下一首/播放暂停/进度条
- 使用 MediaSessionService 支持后台播放及系统媒体会话
- 收藏歌曲、创建和删除歌单、将当前歌曲加入歌单
- SharedPreferences 保存歌曲 URI、歌单、收藏信息
- 歌单和歌曲不依赖在线曲库；应用不包含联网曲库或音乐下载服务

## 构建环境
- Android Studio
- JDK 17
- Android SDK 35
- 首次同步需要网络下载 Gradle/Maven 依赖；构建完成后播放器可离线播放本地文件

## 运行
1. 解压 ZIP。
2. Android Studio > Open，选择项目根目录。
3. 等待 Gradle Sync。
4. 连接 Android 设备或启动模拟器，点击 Run。
5. 通过“＋ 导入”选择手机中的音乐文件。

## 重要限制
- 本项目提供源代码，不是预编译 APK；需使用 Android Studio 构建并在设备上测试。
- 文件 URI 权限由 Android 系统文件选择器授予；如果源文件被移动、删除或权限被撤销，需要重新导入。
- Media3 能否解码 FLAC、WAV、ALAC、APE、DSD 等格式取决于系统/设备解码器和具体编码参数。
- 播放器不会主动将音频转码为 MP3，但 Android 音频输出链路仍可能进行混音或采样率转换；不能承诺全设备 bit-perfect。
- 锁屏媒体会话和后台播放已接入基础服务，最终行为应在目标手机上测试。
