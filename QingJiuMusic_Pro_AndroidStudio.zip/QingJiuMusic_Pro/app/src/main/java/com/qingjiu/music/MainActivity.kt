package com.qingjiu.music

import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import org.json.JSONArray
import org.json.JSONObject

data class Track(val uri: String, val title: String, val artist: String = "本地音频")

class MainActivity : AppCompatActivity() {
    private val tracks = mutableListOf<Track>()
    private val playlists = linkedMapOf<String, MutableSet<String>>()
    private val favorites = mutableSetOf<String>()
    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var controllerFuture: ListenableFuture<MediaController>
    private var controller: MediaController? = null
    private var currentPlaylist: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("qingjiu_music", Context.MODE_PRIVATE) }
    private val tick = object : Runnable {
        override fun run() {
            val c = controller
            val bar = findViewById<SeekBar>(R.id.progressBar)
            if (c != null && c.duration > 0 && !bar.isPressed) {
                bar.progress = ((c.currentPosition.toDouble() / c.duration) * 1000).toInt().coerceIn(0, 1000)
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listView = findViewById(R.id.songList)
        adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_2, android.R.id.text1, mutableListOf()) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = convertView ?: layoutInflater.inflate(android.R.layout.simple_list_item_2, parent, false)
                val track = visibleTracks().getOrNull(position)
                row.findViewById<TextView>(android.R.id.text1).apply {
                    text = track?.title ?: ""; setTextColor(0xFFFFFFFF.toInt()); textSize = 15f
                }
                row.findViewById<TextView>(android.R.id.text2).apply {
                    text = track?.artist ?: ""; setTextColor(0xFF9BA69F.toInt()); textSize = 12f
                }
                row.setBackgroundColor(0xFF101512.toInt())
                return row
            }
        }
        listView.adapter = adapter
        loadLibrary()
        render()
        findViewById<Button>(R.id.importButton).setOnClickListener { importAudio() }
        findViewById<Button>(R.id.newPlaylistButton).setOnClickListener { createPlaylist() }
        findViewById<Button>(R.id.playButton).setOnClickListener {
            val c = controller ?: return@setOnClickListener
            if (c.mediaItemCount == 0 && tracks.isNotEmpty()) playTrack(0)
            else if (c.isPlaying) c.pause() else c.play()
            updatePlayButton()
        }
        findViewById<Button>(R.id.previousButton).setOnClickListener { controller?.seekToPreviousMediaItem() }
        findViewById<Button>(R.id.nextButton).setOnClickListener { controller?.seekToNextMediaItem() }
        findViewById<Button>(R.id.favoriteButton).setOnClickListener {
            val t = currentTrack() ?: return@setOnClickListener
            if (!favorites.add(t.uri)) favorites.remove(t.uri)
            saveLibrary(); updateFavoriteButton()
        }
        listView.setOnItemClickListener { _, _, position, _ ->
            val track = visibleTracks().getOrNull(position) ?: return@setOnItemClickListener
            val index = tracks.indexOfFirst { it.uri == track.uri }
            if (index >= 0) playTrack(index)
        }
        val seek = findViewById<SeekBar>(R.id.progressBar)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) findViewById<TextView>(R.id.nowArtist).text =
                    "${currentTrack()?.artist ?: "本地音频"} · ${formatTime((controller?.duration ?: 0L) * progress / 1000)}"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                val c = controller ?: return
                if (c.duration > 0) c.seekTo(c.duration * seek.progress / 1000)
            }
        })
        handler.post(tick)
        val token = SessionToken(this, ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture.addListener({
            try {
                controller = controllerFuture.get()
                controller?.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) = updatePlayButton()
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = updateNowPlaying()
                    override fun onPlaybackStateChanged(playbackState: Int) = updateNowPlaying()
                })
                updateNowPlaying()
            } catch (_: Exception) { toast("播放器初始化失败，请重启应用") }
        }, mainExecutor)
    }

    private fun importAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, 410)
    }

    @Deprecated("Use Activity Result APIs in a future revision")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 410 || resultCode != RESULT_OK || data == null) return
        val found = mutableListOf<Uri>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) found.add(clip.getItemAt(i).uri) }
        data.data?.let { if (found.isEmpty()) found.add(it) }
        var count = 0
        found.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val key = uri.toString()
            if (tracks.none { it.uri == key }) { tracks.add(Track(key, queryName(uri))); count++ }
        }
        saveLibrary(); render()
        toast(if (count > 0) "已导入 $count 首歌曲" else "没有新增歌曲")
    }

    private fun queryName(uri: Uri): String {
        var name = "未知歌曲"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        return name.substringBeforeLast('.', name)
    }

    private fun playTrack(index: Int) {
        val c = controller ?: run { toast("播放器正在初始化，请稍后重试"); return }
        if (tracks.isEmpty()) return
        val items = tracks.map { t ->
            MediaItem.Builder().setUri(Uri.parse(t.uri)).setMediaMetadata(
                MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).build()
            ).build()
        }
        c.setMediaItems(items, index.coerceIn(0, items.lastIndex), 0L)
        c.prepare(); c.play(); updateNowPlaying()
    }

    private fun currentTrack(): Track? {
        val uri = controller?.currentMediaItem?.localConfiguration?.uri?.toString() ?: return null
        return tracks.find { it.uri == uri }
    }

    private fun updateNowPlaying() {
        val t = currentTrack()
        findViewById<TextView>(R.id.nowTitle).text = t?.title ?: "尚未播放"
        findViewById<TextView>(R.id.nowArtist).text = t?.artist ?: "导入本地音频开始播放"
        updateFavoriteButton(); updatePlayButton()
    }

    private fun updateFavoriteButton() {
        val t = currentTrack()
        findViewById<Button>(R.id.favoriteButton).text = if (t != null && favorites.contains(t.uri)) "♥" else "♡"
    }

    private fun updatePlayButton() {
        findViewById<Button>(R.id.playButton).text = if (controller?.isPlaying == true) "Ⅱ" else "▶"
    }

    private fun createPlaylist() {
        val input = EditText(this).apply { hint = "例如：通勤、收藏、纯音乐" }
        AlertDialog.Builder(this).setTitle("创建歌单").setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("创建") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isBlank()) { toast("歌单名称不能为空"); return@setPositiveButton }
                if (playlists.containsKey(name)) { toast("歌单已存在"); return@setPositiveButton }
                playlists[name] = linkedSetOf()
                saveLibrary(); renderPlaylists(); toast("歌单已创建")
            }.show()
    }

    private fun renderPlaylists() {
        val box = findViewById<LinearLayout>(R.id.playlistContainer)
        box.removeAllViews()
        box.addView(Button(this).apply { text = "全部歌曲"; setOnClickListener { currentPlaylist = null; render() } })
        box.addView(Button(this).apply { text = "♥ 收藏"; setOnClickListener { currentPlaylist = "#favorites"; render() } })
        playlists.keys.toList().forEach { name ->
            box.addView(Button(this).apply {
                text = name
                setOnClickListener {
                    currentPlaylist = name; render()
                    AlertDialog.Builder(this@MainActivity).setTitle(name)
                        .setItems(arrayOf("添加当前播放歌曲", "删除此歌单")) { _, which ->
                            when (which) {
                                0 -> {
                                    val t = currentTrack()
                                    if (t == null) toast("请先播放一首歌曲")
                                    else { playlists[name]?.add(t.uri); saveLibrary(); render() }
                                }
                                1 -> { playlists.remove(name); if (currentPlaylist == name) currentPlaylist = null; saveLibrary(); render() }
                            }
                        }.show()
                }
            })
        }
    }

    private fun visibleTracks(): List<Track> = when (currentPlaylist) {
        "#favorites" -> tracks.filter { favorites.contains(it.uri) }
        null -> tracks
        else -> tracks.filter { playlists[currentPlaylist]?.contains(it.uri) == true }
    }

    private fun render() {
        adapter.clear()
        adapter.addAll(visibleTracks().map { it.title })
        adapter.notifyDataSetChanged()
        findViewById<TextView>(R.id.libraryLabel).text = (currentPlaylist ?: "全部歌曲") + " · ${visibleTracks().size} 首"
        renderPlaylists()
    }

    private fun saveLibrary() {
        val root = JSONObject()
        root.put("tracks", JSONArray().apply { tracks.forEach { put(JSONObject().put("uri", it.uri).put("title", it.title).put("artist", it.artist)) } })
        root.put("favorites", JSONArray().apply { favorites.forEach { put(it) } })
        val p = JSONObject()
        playlists.forEach { (name, ids) -> p.put(name, JSONArray().apply { ids.forEach { put(it) } }) }
        root.put("playlists", p)
        prefs.edit { putString("library_json", root.toString()) }
    }

    private fun loadLibrary() {
        try {
            val root = JSONObject(prefs.getString("library_json", "{}") ?: "{}")
            val arr = root.optJSONArray("tracks") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                tracks.add(Track(o.getString("uri"), o.optString("title", "未知歌曲"), o.optString("artist", "本地音频")))
            }
            val fav = root.optJSONArray("favorites") ?: JSONArray()
            for (i in 0 until fav.length()) favorites.add(fav.getString(i))
            val p = root.optJSONObject("playlists") ?: JSONObject()
            p.keys().forEach { name ->
                val ids = linkedSetOf<String>()
                val a = p.optJSONArray(name) ?: JSONArray()
                for (i in 0 until a.length()) ids.add(a.getString(i))
                playlists[name] = ids
            }
        } catch (_: Exception) { toast("本地音乐库读取失败") }
    }

    private fun formatTime(ms: Long): String {
        val seconds = (ms / 1000).coerceAtLeast(0)
        return "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        if (::controllerFuture.isInitialized) MediaController.releaseFuture(controllerFuture)
        super.onDestroy()
    }
}
